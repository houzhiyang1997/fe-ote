import os
import ast


def process_line(line):
    # str-->list
    return ast.literal_eval(line)


def generate_string(length):
    if length == 0:
        return ''
    elif length == 1:
        return 'B'
    else:
        return 'B' + 'I' * (length - 1)


def process_files(source_path, target_path, new_path):
    # 读取列表文件
    with open(source_path, 'r', encoding='utf-8') as file1:
        lines = file1.readlines()
    processed_lines_cleaned = []
    for line in lines:
        if '，' in line:
            elements = line.strip().strip('[]').split('，')
        elif ', ' in line:
            elements = line.strip().strip('[]').split(', ')
        elif ',' in line:
            elements = line.strip().strip('[]').split(',')
        else:
            elements = [line.strip().strip('[]')]
        # print(type(elements))
        processed_lines_cleaned.append(elements)

    # 读取并处理目标文本文件
    with open(target_path, 'r', encoding='utf-8') as file2:
        texts = file2.readlines()
    processed_texts_cleaned = []
    for i, text in enumerate(texts):
        for element in processed_lines_cleaned[i]:
            text = text.replace(element, generate_string(len(element)))
        processed_texts_cleaned.append(text)
    # print(texts)
    # 将处理后的文本写回同名文件
    with open(new_path, 'w', encoding='utf-8') as new_file:
        for processed_text in processed_texts_cleaned:
            # print(processed_text)
            new_file.write(processed_text)


# 源文件夹和目标文件夹路径
source_folder = r'.\dataset\test\true_label'
target_folder = r'.\dataset\test\only_content'
new_folder = r'.\dataset\test\tag2id\true_label2id'

# 遍历源文件夹中的所有文件
for filename in os.listdir(source_folder):
    if filename.endswith('.txt'):  # 确保只处理.txt文件
        source_path = os.path.join(source_folder, filename)
        target_path = os.path.join(target_folder, filename)
        new_path = os.path.join(new_folder, filename)
        process_files(source_path, target_path, new_path)
